export class Flight {

    constructor(
     public flightNumber:string='',
     public departureCity: string='',
     public arrivalCity:string ='',
     public departureDate:string ='',
     public availableSeats: number=0,
     public flightClass: string ='',
    ){}
    
 }