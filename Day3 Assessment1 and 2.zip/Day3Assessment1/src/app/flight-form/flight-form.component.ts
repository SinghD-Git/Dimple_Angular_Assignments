import { Component } from '@angular/core';
import { Flight } from './flight.model';

@Component({
  selector: 'app-flight-form',
  templateUrl: './flight-form.component.html',
  styleUrl: './flight-form.component.css'
})
export class FlightFormComponent {

  flight = new Flight();

  onSubmit(form:any) {
    if(form.valid){
       console.log(' flight detail is submitted', this.flight)
       //form.resetForm()
    }
  }

}
