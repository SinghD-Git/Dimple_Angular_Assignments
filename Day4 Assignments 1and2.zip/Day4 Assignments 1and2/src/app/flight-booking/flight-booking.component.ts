import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-flight-booking',
  templateUrl: './flight-booking.component.html',
  styleUrls: ['./flight-booking.component.css']
})
export class FlightBookingComponent implements OnInit {

  bookingForm!: FormGroup;
  submittedBooking: any;
  showSuccessMessage: boolean | undefined;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.bookingForm = this.fb.group({
      passengerName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', [Validators.required, Validators.pattern(/^\+?\d{10,15}$/)]],
      departureAirport: ['', Validators.required],
      arrivalAirport: ['', Validators.required],
      travelDate: ['', Validators.required],
      numberOfPassengers: [1, [Validators.required, Validators.min(1)]]
    });
  }

  onSubmit() {
    if (this.bookingForm.valid) {
      this.submittedBooking = this.bookingForm.value;  // save form data
      this.showSuccessMessage = true; 
      this.bookingForm.reset();
    } else {
      alert('Please fill in all required fields correctly.');
    }
  }

}
