import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-passenger-registration',
  templateUrl: './passenger-registration.component.html',
  styleUrl: './passenger-registration.component.css'
})
export class PassengerRegistrationComponent implements OnInit {

  registrationForm!: FormGroup;
  submittedRegistration: any;
  showSuccessMessage: boolean | undefined;

  nationalities: string[] = ['India', 'USA', 'UK', 'Canada'];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.registrationForm = this.fb.group({
      passengerName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', [Validators.required, Validators.minLength(10)]],
      passportNumber: ['', [Validators.required, Validators.minLength(6)]],
      dateOfBirth: ['', [Validators.required, this.minAgeValidator(18)]],
      nationality: ['',Validators.required]
    });
  }
  
 // Custom validator for age
 minAgeValidator(minAge: number) {
  return (control: AbstractControl) => {
    const birthDate = new Date(control.value);
    const today = new Date();
    const age = today.getFullYear() - birthDate.getFullYear();
    const isOldEnough = age > minAge || (age === minAge && today >= new Date(birthDate.setFullYear(today.getFullYear())));
    return isOldEnough ? null : { minAge: true };
  };
}

  onSubmit() {
    if (this.registrationForm.valid) {
      this.submittedRegistration = this.registrationForm.value;  // save form data
      this.showSuccessMessage = true; 
      this.registrationForm.reset();
    } else {
      alert('Please fill in all required fields correctly.');
    }
  } 

}
