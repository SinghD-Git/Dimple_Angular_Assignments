import { Component } from '@angular/core';

@Component({
  selector: 'app-flight-list',
  templateUrl: './flight-list.component.html',
  styleUrls: ['./flight-list.component.css']
})
export class FlightListComponent {
  flights = [
    { id: 1, name: 'Indigo E6547' },
    { id: 2, name: 'Spicejet SJ453' },
    { id: 3, name: 'AirIndia AI303' },
    { id: 2, name: 'GoAir GA4535' },
    { id: 3, name: 'AirAsia AA3037' }
  ];
}