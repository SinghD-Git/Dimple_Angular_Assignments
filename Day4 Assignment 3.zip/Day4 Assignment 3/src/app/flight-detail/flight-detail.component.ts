import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-flight-detail',
  templateUrl: './flight-detail.component.html',
  styleUrls: ['./flight-detail.component.css']
})
export class FlightDetailComponent implements OnInit {
  flightId: string | null = null;
  flight: any = null;

  flights = [
    {
      id: '1',
      flightNumber: 'E65101',
      origin: 'New York',
      destination: 'Delhi',
      departureDate: '2025-07-20',
      status: 'on-time'
    },
    {
      id: '2',
      flightNumber: 'SJ4204',
      origin: 'London',
      destination: 'Mumbai',
      departureDate: '2025-07-21',
      status: 'delayed'
    },
    {
      id: '3',
      flightNumber: 'AI3303',
      origin: 'Dubai',
      destination: 'Bangalore',
      departureDate: '2025-07-22',
      status: 'cancelled'
    }
  ];

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.flightId = this.route.snapshot.paramMap.get('id');
    this.flight = this.flights.find(f => f.id === this.flightId);
  }
}
