import { Component, OnInit } from '@angular/core';
import { FlightService } from '../flight.service';
import { Flight } from './flight.model';

@Component({
  selector: 'app-flight',
  templateUrl: './flight.component.html',
  styleUrls: ['./flight.component.css']
})
export class FlightComponent implements OnInit {
  flights: Flight[] = [];
  showAddFlight: boolean = false;

  // Object to hold form data
  newFlight: Flight = {
    flightNumber: '',
    airline: '',
    from: '',
    to: '',
    departureTime: '',
    arrivalTime: '',
    duration: '',
    price: 0,
    currency: 'USD',
    seatsAvailable: 0,
    status: 'On Time'
  };

  constructor(private flightService: FlightService) {}

  ngOnInit(): void {
    this.flightService.getAllFlights().subscribe((data) => {
      this.flights = data;
    });
  }

  deleteFlight(flightNumber: string): void {
    if (confirm(`Are you sure you want to delete flight ${flightNumber}?`)) {
      this.flights = this.flights.filter(flight => flight.flightNumber !== flightNumber);
    }
  }

  addFlight(): void {
    if (this.newFlight.flightNumber) {
      this.flights.push({ ...this.newFlight });
      this.resetNewFlight();
      this.showAddFlight = false;
    }
  }

  resetNewFlight(): void {
    this.newFlight = {
      flightNumber: '',
      airline: '',
      from: '',
      to: '',
      departureTime: '',
      arrivalTime: '',
      duration: '',
      price: 0,
      currency: '',
      seatsAvailable: 0,
      status: ''
    };
  }

  editFlight(flight: Flight): void {
    this.newFlight = { ...flight };
    this.showAddFlight = true;
  }
}
