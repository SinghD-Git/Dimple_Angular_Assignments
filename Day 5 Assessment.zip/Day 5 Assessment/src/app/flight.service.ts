import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { Flight } from './flight/flight.model';

@Injectable({
  providedIn: 'root'
})
export class FlightService {
  private apiUrl = 'https://mocki.io/v1/fcce0040-895b-47cf-a2a0-d7250e71d4e9';

  constructor(private http: HttpClient) {}

  getAllFlights(): Observable<Flight[]> {
    return this.http.get<{ flights: Flight[] }>(this.apiUrl).pipe(
      map(response => response.flights)
    );
  }
}
