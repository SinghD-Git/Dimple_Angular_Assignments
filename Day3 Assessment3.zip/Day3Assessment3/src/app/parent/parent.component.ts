import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html'
})
export class ParentComponent {
  flight = {
    flightNumber: 'AI202',
    destination: 'New York',
    departureTime: '13:00'
  };

  bookingConfirmed = false;

  onFlightBooked() {
    this.bookingConfirmed = true;
  }
}