import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html'
})
export class ChildComponent {
  @Input() flightNumber!: string;
  @Input() destination!: string;
  @Input() departureTime!: string;

  @Output() bookFlight = new EventEmitter<void>(); 

  onBookFlight() {
    this.bookFlight.emit();
  }
}