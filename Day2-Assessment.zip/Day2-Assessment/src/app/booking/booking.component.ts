import { Component } from '@angular/core';
import { Booking } from '../booking';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.css'
})
export class BookingComponent {
  booking : Booking = {
    flightNumber:'',
    passengerName:''
  };

  confirmedBooking: Booking | null =  null;

  constructor(private bookingService: BookingService) {}

  submitBooking(): void {
    this.bookingService.saveBooking(this.booking);
    this.confirmedBooking = {flightNumber: this.booking.flightNumber, passengerName: this.booking.passengerName};
  }

}
