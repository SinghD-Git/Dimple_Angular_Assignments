export class Booking{
    flightNumber: string;
    passengerName: string;


    constructor(flightNumber:string,passengerName: string  )
    {
        this.flightNumber = flightNumber;
        this.passengerName = passengerName;
    }
}