import { Component } from '@angular/core';
import { Flight } from '../flight';
import { FlightService } from '../flight.service';

@Component({
  selector: 'app-flight-list',
  templateUrl: './flight-list.component.html',
  styleUrl: './flight-list.component.css'
})
export class FlightListComponent {
  flights: Flight[] =[];

  constructor(private flightService: FlightService) {
    this.flights = this.flightService.getFlights();
  }
}
