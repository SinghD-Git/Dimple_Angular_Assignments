export class Flight{

    flightNumber: string;
    origin: string;
    destination: string;
    departureTime: string;
    flightType: string;
    totalSeats: number;
    availableSeats: number;


    constructor(flightNumber:string, origin:string, destination:string, departureTime:string, flightType:string, totalSeats:number, availableSeats:number )
    {
        this.flightNumber = flightNumber;
        this.origin = origin;
        this.destination = destination;
        this.departureTime = departureTime;
        this.flightType = flightType;
        this.totalSeats = totalSeats;
        this.availableSeats = availableSeats;
    }
}