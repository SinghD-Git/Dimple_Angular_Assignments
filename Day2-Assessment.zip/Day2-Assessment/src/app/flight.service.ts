import { Injectable } from "@angular/core";
import { Flight } from "./flight";

@Injectable({
    providedIn: 'root'
})
export class FlightService{

    public getFlights(){

        let flights: Flight[];

        flights = [
            new Flight('6E001', 'Delhi', 'Mumbai', '13:00', 'Indigo', 100,20),
            new Flight('AI002', 'Pune', 'Bangalore', '8:00', 'AirIndia', 150,35),
            new Flight('SJ003', 'Goa', 'Chennai', '20:00', 'SpiceJet', 120,15),
            new Flight('GA004', 'Mumbai', 'Nagpur', '16:00', 'GoAir', 80,10),
            new Flight('AA005', 'Kolkata', 'Delhi', '09:00', 'AirAsia', 110,23),
        ]
        return flights;
    }
}