import { Injectable } from "@angular/core";
import { Booking } from "./booking";

@Injectable({
    providedIn: 'root'
})
export class BookingService{

    private bookings: Booking[] =[];

    constructor() {}

    saveBooking(booking: Booking): void {
        this.bookings.push(booking);
    }

    getBookings(): Booking[] {
        return this.bookings;
    }
}